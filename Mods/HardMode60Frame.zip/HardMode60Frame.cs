// =====================================================================
//  HardMode60Frame  v1.2
//  뿌리 거둠(하드 모드) 60단계 이상을 깬 코스튬을 특별하게 꾸밉니다.
//
//  게임 원본 동작 (UI_CostumeListElement.Initialize 를 뜯어본 결과)
//    - 아이콘 테두리 : 일반 클리어 횟수("CostumeCleared_<id>")
//    - 이름 테두리   : 하드 모드 최고 단계("HardModeClearedHighestPoint_Costume_<id>")
//                      15↑ 골드 / 30↑ 플래티넘 / 40↑ 에메랄드 / 50↑ 다이아
//                      → 50 이 마지막이라 50 이든 60 이든 똑같이 보입니다.
//
//  이 모드가 하는 일 (60 이상일 때)
//    - 코스튬 이름 글씨를 '결속(듀얼) 아티팩트 이름'과 같은 두 색 그라데이션으로
//      (게임의 UI_CharmTooltip 이 결속 아티팩트 이름을 칠하는 방식 그대로)
//    - 캐릭터 아이콘 주위로 아우라 파티클이 피어오름
//    (테두리는 게임 원본 그대로 둡니다)
// =====================================================================

using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace HardMode60Frame
{
    public class HardMode60FrameMod : HorayModBase
    {
        public const string HOST_NAME = "HardMode60Frame_Host";

        protected override void OnModLoaded()
        {
            Debug.Log("[HardMode60Frame] 모드 로드됨");

            // 게임이 애드온을 다시 불러올 때 두 개가 겹치지 않도록 정리
            for (int i = 0; i < 8; i++)
            {
                GameObject stale = GameObject.Find(HOST_NAME);
                if (stale == null) break;
                UnityEngine.Object.DestroyImmediate(stale);
            }

            GameObject host = new GameObject(HOST_NAME);
            UnityEngine.Object.DontDestroyOnLoad(host);
            host.AddComponent<FrameWatcher>();
        }
    }

    // =================================================================
    //  코스튬 목록을 지켜보다가 60단계 이상인 칸을 꾸며주는 감시자
    // =================================================================
    public class FrameWatcher : MonoBehaviour
    {
        // ---- 여기 숫자를 바꾸면 조건이 바뀝니다 ----
        private const int THRESHOLD = 60;

        // 이름 그라데이션 위쪽 색으로 쓸 등급 (Rare = 희귀, Legend = 전설)
        private const EItemRarity NAME_RARITY = EItemRarity.Rare;

        private static FrameWatcher _instance;

        private UI_CostumePanel _panel;
        private UI_CostumeListElement[] _elements;
        private float _rescanTimer;
        private bool _loggedOnce;

        private readonly HashSet<int> _styled = new HashSet<int>();

        private void Awake()
        {
            if (_instance != null && _instance != this) { Destroy(gameObject); return; }
            _instance = this;
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        // LateUpdate 는 게임의 Update 가 모두 끝난 뒤에 돕니다.
        // 창이 열리면서 게임이 칸을 채운 '바로 그 프레임'에 덧칠하므로
        // 원래 모습이 한 순간 스쳐 보이지 않습니다.
        private void LateUpdate()
        {
            try
            {
                RefreshTargets();
                Apply();
            }
            catch (Exception e)
            {
                if (!_loggedOnce)
                {
                    _loggedOnce = true;
                    Debug.LogWarning("[HardMode60Frame] 오류: " + e);
                }
            }
        }

        // 코스튬 창과 그 안의 칸 목록을 찾아둡니다 (매 프레임 찾으면 무거움)
        private void RefreshTargets()
        {
            _rescanTimer -= Time.unscaledDeltaTime;

            bool panelGone = (_panel == null);
            if (!panelGone && _elements != null && _rescanTimer > 0f) return;

            if (panelGone)
            {
                UI_CostumePanel[] panels = Resources.FindObjectsOfTypeAll<UI_CostumePanel>();
                if (panels != null)
                {
                    for (int i = 0; i < panels.Length; i++)
                    {
                        if (panels[i] != null) { _panel = panels[i]; break; }
                    }
                }
            }

            if (_panel != null)
                _elements = _panel.GetComponentsInChildren<UI_CostumeListElement>(true);

            _rescanTimer = 0.5f;   // 목록은 0.5초마다만 다시 훑습니다
        }

        private void Apply()
        {
            if (_elements == null || _elements.Length == 0) return;

            SaveData save = SaveManager.Current;
            if (save == null) return;

            for (int i = 0; i < _elements.Length; i++)
            {
                UI_CostumeListElement el = _elements[i];
                if (el == null || !el.gameObject.activeInHierarchy) continue;

                CostumeEntity costume = el.Costume;
                if (costume == null || string.IsNullOrEmpty(costume.id)) continue;

                int point = save.GetInt("HardModeClearedHighestPoint_Costume_" + costume.id, 0);
                bool top = point >= THRESHOLD;

                int key = el.GetInstanceID();

                // ── 코스튬 이름 글씨 ──────────────────────────────
                TMP_Text nameText = el.nameText;
                if (nameText != null)
                {
                    if (top)
                    {
                        if (!nameText.enableVertexGradient) ApplyDualNameStyle(nameText);
                        _styled.Add(key);

                        if (!_loggedOnce)
                        {
                            _loggedOnce = true;
                            Debug.Log("[HardMode60Frame] '" + costume.id + "' 적용 (기록 "
                                      + point + "단계)");
                        }
                    }
                    else if (_styled.Contains(key))
                    {
                        nameText.enableVertexGradient = false;
                        _styled.Remove(key);
                    }
                }

                // ── 아이콘 아우라 ─────────────────────────────────
                UpdateAura(el, top);
            }
        }

        // -------------------------------------------------------------
        // 결속 아티팩트 이름과 같은 두 색 그라데이션
        //   위쪽 두 꼭짓점 = 아이템 등급 색
        //   아래쪽 두 꼭짓점 = 'ItemRarity_Dual' 키워드 색
        // -------------------------------------------------------------
        private void ApplyDualNameStyle(TMP_Text text)
        {
            KeywordEntity dualKeyword = KeywordDatabase.GetEntity("ItemRarity_Dual");
            if (dualKeyword == null) return;

            Color top = ItemDatabase.GetColorViaItemRarity(NAME_RARITY);
            Color bottom = dualKeyword.textColor;

            text.color = Color.white;              // 그라데이션이 그대로 보이도록 흰색
            text.colorGradient = new VertexGradient(top, top, bottom, bottom);
            text.enableVertexGradient = true;
        }

        // -------------------------------------------------------------
        // 아이콘 칸에 아우라를 붙이거나 떼어냅니다
        // -------------------------------------------------------------
        private void UpdateAura(UI_CostumeListElement el, bool wanted)
        {
            if (el.iconImage == null) return;

            // 아이콘이 들어 있는 칸(부모)에 붙입니다. 아이콘보다 조금 넓어서
            // 파티클이 주변으로 퍼질 공간이 생깁니다.
            RectTransform slot = el.iconImage.rectTransform.parent as RectTransform;
            if (slot == null) slot = el.iconImage.rectTransform;

            IconAura aura = slot.GetComponent<IconAura>();

            if (wanted)
            {
                if (aura == null) slot.gameObject.AddComponent<IconAura>();
            }
            else if (aura != null)
            {
                aura.Cleanup();
                Destroy(aura);
            }
        }
    }

    // =================================================================
    //  아이콘 주위로 피어오르는 아우라 파티클
    //  (유니티 파티클 시스템은 UI 위에 그리기가 까다로워서,
    //   작은 이미지 몇 개를 직접 움직이는 방식으로 만들었습니다)
    // =================================================================
    public class IconAura : MonoBehaviour
    {
        private const int COUNT = 10;

        // 아우라 색 (위로 갈수록 옅어집니다)
        private static readonly Color AURA_COLOR = new Color(1f, 0.45f, 0.25f);

        private static Sprite _dot;

        private RectTransform _area;
        private RectTransform[] _parts;
        private Image[] _images;
        private float[] _phase;
        private float[] _speed;
        private float[] _x;
        private float[] _size;

        private void Awake()
        {
            _area = transform as RectTransform;
            if (_area == null) { enabled = false; return; }

            EnsureDot();

            _parts = new RectTransform[COUNT];
            _images = new Image[COUNT];
            _phase = new float[COUNT];
            _speed = new float[COUNT];
            _x = new float[COUNT];
            _size = new float[COUNT];

            Rect r = _area.rect;

            for (int i = 0; i < COUNT; i++)
            {
                GameObject go = new GameObject("HM60_Aura_" + i, typeof(RectTransform));
                RectTransform rt = go.GetComponent<RectTransform>();
                rt.SetParent(_area, false);
                rt.anchorMin = new Vector2(0.5f, 0.5f);
                rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.pivot = new Vector2(0.5f, 0.5f);

                Image img = go.AddComponent<Image>();
                img.sprite = _dot;
                img.raycastTarget = false;          // 클릭을 막지 않게
                img.color = AURA_COLOR;

                _parts[i] = rt;
                _images[i] = img;
                _phase[i] = UnityEngine.Random.value;                 // 시작 시점을 흩뿌림
                _speed[i] = UnityEngine.Random.Range(0.45f, 0.8f);
                _x[i] = UnityEngine.Random.Range(-r.width * 0.42f, r.width * 0.42f);
                _size[i] = UnityEngine.Random.Range(3f, 6f);

                rt.sizeDelta = new Vector2(_size[i], _size[i]);
            }
        }

        private void Update()
        {
            if (_parts == null || _area == null) return;

            Rect r = _area.rect;
            float dt = Time.unscaledDeltaTime;

            for (int i = 0; i < COUNT; i++)
            {
                if (_parts[i] == null) continue;

                _phase[i] += dt * _speed[i];
                if (_phase[i] >= 1f)
                {
                    _phase[i] -= 1f;
                    // 한 바퀴 돌 때마다 새 위치에서 다시 피어오릅니다
                    _x[i] = UnityEngine.Random.Range(-r.width * 0.42f, r.width * 0.42f);
                    _size[i] = UnityEngine.Random.Range(3f, 6f);
                    _parts[i].sizeDelta = new Vector2(_size[i], _size[i]);
                }

                float t = _phase[i];

                // 아래에서 위로 떠오르며 좌우로 살짝 흔들림
                float y = Mathf.Lerp(-r.height * 0.45f, r.height * 0.55f, t);
                float wobble = Mathf.Sin(t * 6.283f + i) * 2.5f;
                _parts[i].anchoredPosition = new Vector2(_x[i] + wobble, y);

                // 나타났다가 사라지는 밝기 (가운데서 가장 진함)
                Color c = AURA_COLOR;
                c.a = Mathf.Sin(t * 3.1416f) * 0.85f;
                _images[i].color = c;
            }
        }

        public void Cleanup()
        {
            if (_parts == null) return;
            for (int i = 0; i < _parts.Length; i++)
            {
                if (_parts[i] != null) Destroy(_parts[i].gameObject);
            }
            _parts = null;
        }

        private void OnDestroy()
        {
            Cleanup();
        }

        // 가장자리가 부드러운 작은 점 그림을 코드로 만들어 씁니다
        private static void EnsureDot()
        {
            if (_dot != null) return;

            const int SIZE = 16;
            Texture2D tex = new Texture2D(SIZE, SIZE, TextureFormat.RGBA32, false);
            tex.hideFlags = HideFlags.HideAndDontSave;
            tex.filterMode = FilterMode.Bilinear;

            Vector2 center = new Vector2((SIZE - 1) * 0.5f, (SIZE - 1) * 0.5f);
            float radius = SIZE * 0.5f;

            for (int y = 0; y < SIZE; y++)
            {
                for (int x = 0; x < SIZE; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), center) / radius;
                    float a = Mathf.Clamp01(1f - d);
                    a = a * a;                       // 가운데는 진하고 바깥은 빠르게 옅어지게
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            tex.Apply();

            _dot = Sprite.Create(tex, new Rect(0f, 0f, SIZE, SIZE), new Vector2(0.5f, 0.5f));
            _dot.hideFlags = HideFlags.HideAndDontSave;
        }
    }
}
