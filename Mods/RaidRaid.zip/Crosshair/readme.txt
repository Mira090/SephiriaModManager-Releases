RaidRaid 조준점 사용자 이미지 안내

이 폴더(AddOns\RaidRaid\Crosshair)에 이미지 파일을 넣으면
게임 옵션 → 조준점 모양 목록 맨 뒤에 파일 이름 그대로 추가됩니다.
옵션 창을 열 때마다 폴더를 다시 읽으므로 게임을 재시작할 필요는 없습니다.
(적용은 자기 화면에만 됩니다. 각자 자기 폴더에 넣어 고르면 됩니다.)

쓸 수 있는 파일
- 이름.png : 그림 한 장. 투명 배경 PNG(32비트 RGBA).
- 이름.cur : 윈도우 커서 파일. 기준점은 파일에 저장된 끝점을 그대로 씁니다. 크기가 여러 개 들어 있으면 가장 작은 것(64x64 이하 중)을 씁니다.
- 이름.ani : 윈도우 움직이는 커서 파일. 프레임과 프레임 간격(속도)을 파일에 저장된 대로 반복 재생합니다. 기준점은 파일의 끝점입니다.
  같은 이름으로 여러 형식이 있으면 ani → cur → png 순으로 하나만 씁니다.
- 어떤 형식이든 최대 64x64 픽셀. 넘으면 무시하고 Player.log에 안내가 남습니다.

크기
- 100%에서 그림 1픽셀 = 게임 UI 1픽셀(1440p 화면에서 4픽셀). 기본 조준점은 28x33입니다.
- 크기 슬라이더(10~300%)는 그림을 그대로 두고 표시만 줄이거나 키웁니다. 큰 그림(예: 48x48)을 50%로 줄여도 디테일이 그대로입니다.
  1440p에서는 25% / 50% / 75% / 100% / 125%…, 1080p에서는 33% / 67% / 100% / 133%…처럼 그림 1픽셀이 화면 픽셀 정수 배가 되는 값에서 가장 선명합니다.
  그 밖의 값에서는 사용자 이미지를 픽셀이 고르지 않게 되는 대신 부드럽게(보간) 그립니다. (기본 조준점과 내장 모양은 항상 픽셀 단위로 그립니다.)

조준 기준점(마우스 위치에 놓이는 픽셀) — PNG일 때
- 그림 안에 분홍색 #FF00FF (R255 G0 B255) 픽셀을 하나 찍으면 그 자리가 기준점이 되고,
  그 픽셀은 흰색 점으로 그려집니다(색상 슬라이더가 적용됨). 기본 조준점처럼 가운데 점을 두고
  싶으면 점 자리에 마커를 찍고 그 둘레를 검정으로 두르면 됩니다. (sample_plus.png 참고)
  마커는 하나만 찍으세요. 여러 개면 처음 찾은 것을 씁니다.
  가운데가 빈 조준점(원형 등)을 원하면 마커를 찍지 말고 가로·세로를 홀수 크기(예: 33x33)로
  만드세요. 마커가 없으면 그림 정중앙 픽셀이 기준점이 됩니다. (sample_ring.png 참고)
- cur/ani 파일은 마커를 보지 않고 파일에 저장된 끝점을 기준점으로 씁니다. (예: doro.ani는 왼쪽 위 모서리)

색
- 흰색이나 밝은 회색으로 그리면 옵션의 색상 R/G/B 슬라이더로 색을 바꿀 수 있습니다.
  (색이 곱해지는 방식이라 검은 테두리는 검정으로 남습니다.)
  처음부터 색을 넣어 그린 그림(doro.ani 등)은 슬라이더를 255로 두면 그대로 나옵니다.
- 반투명 픽셀도 그대로 표시됩니다.

예시: sample_plus.png (33x33, 가운데 마커 = 흰 점), sample_ring.png (33x33, 마커 없음 = 정중앙이 빈 기준점)

----------------------------------------------------------------
RaidRaid custom crosshair

Put image files in this folder (AddOns\RaidRaid\Crosshair). They appear at the end of
Options -> Crosshair Shape, named after the file. The folder is re-read every time the
options panel opens, so no restart is needed. Applies to your own screen only.

- Files: name.png (transparent 32-bit PNG), name.cur (Windows cursor; aim point = its hot spot; the smallest
  image up to 64x64 is used), name.ani (Windows animated cursor; frames and timing from the file, looped).
  If several formats share a name, ani > cur > png. Everything must be 64x64 or smaller (larger files are ignored, see Player.log).
- At 100%, 1 image pixel = 1 game UI pixel (4 screen pixels at 1440p). The default crosshair is 28x33.
  The size slider scales the display only, so a 48x48 image at 50% keeps its detail. Sharpest at values where one
  image pixel becomes a whole number of screen pixels (1440p: 25/50/75/100%..., 1080p: 33/67/100%...);
  other values draw custom images smoothed.
- Aim point for PNG: paint one magenta #FF00FF (R255 G0 B255) pixel; that pixel becomes the aim point and is
  drawn as a white dot (tinted by the color sliders). For a hollow center, use no marker and an odd
  image size (e.g. 33x33): the center pixel is then the aim point. cur/ani files use their stored hot spot.
- Draw in white / light gray so the Color R/G/B sliders can tint it (colors are multiplied, black stays black).
